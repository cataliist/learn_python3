from distutils.core import setup

setup(

    name            = 'cataliistSanitizer',
    version         = '1.0.0',
    py_modules      = ['cataliistSanitizer'],
    author          = 'cataliist',
    author_email    = 'cataliistceo@gmail.com',
    url             = 'http://www.cataliist.com',
    description     = 'a simple "-" and ":" replacer with ".""',
)