from distutils.core import setup

setup(

    name            = 'cataliistNester',
    version         = '1.3.0',
    py_modules      = ['cataliistNester'],
    author          = 'cataliist',
    author_email    = 'cataliistceo@gmail.com',
    url             = 'http://www.cataliist.com',
    description     = 'a simple printer for nested lists',
)