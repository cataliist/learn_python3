from distutils.core import setup

setup(

    name            = 'cataliistFilePicker',
    version         = '1.2.0',
    py_modules      = ['cataliistFilePicker'],
    author          = 'cataliist',
    author_email    = 'cataliistceo@gmail.com',
    url             = 'http://www.cataliist.com',
    description     = 'a simple file graber',
    long_description= 'cataliistFilePicker v.1.2.0 is class enabled with list inheritence'
)