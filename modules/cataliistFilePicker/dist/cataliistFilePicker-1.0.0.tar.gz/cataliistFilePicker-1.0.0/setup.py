from distutils.core import setup

setup(

    name            = 'cataliistFilePicker',
    version         = '1.0.0',
    py_modules      = ['cataliistFilePicker'],
    author          = 'cataliist',
    author_email    = 'cataliistceo@gmail.com',
    url             = 'http://www.cataliist.com',
    description     = 'a simple file graber',
)