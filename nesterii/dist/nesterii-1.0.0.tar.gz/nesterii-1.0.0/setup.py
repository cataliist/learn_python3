from distutils.core import setup

setup(

    name            = 'nesterii',
    version         = '1.0.0',
    py_modules      = ['nesterii'],
    author          = 'cataliist',
    author_email    = 'cataliistceo@gmail.com',
    url             = 'http://www.cataliist.com',
    description     = 'a simple printer for nested lists',
)